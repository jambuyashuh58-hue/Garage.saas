/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Using the pages/ router for simplicity
};
module.exports = nextConfig;